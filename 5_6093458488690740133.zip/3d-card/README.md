# 3D Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/gayane-gasparyan/pen/wvxewXO](https://codepen.io/gayane-gasparyan/pen/wvxewXO).

3D effect on card hover