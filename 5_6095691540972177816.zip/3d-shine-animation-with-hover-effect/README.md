# 3D shine animation with hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/gOQMMMj](https://codepen.io/t_afif/pen/gOQMMMj).

CSS Tip!
https://twitter.com/ChallengesCss/status/1670794056262139907

Chrome only for now